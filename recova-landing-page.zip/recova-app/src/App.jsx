import React from 'react';

export default function App() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-6">
      <div className="max-w-3xl text-center">
        <h1 className="text-4xl md:text-5xl font-bold mb-6">Recova – The Backup Your Crypto Actually Deserves</h1>
        <p className="text-lg md:text-xl mb-6">
          What happens if you lose your wallet? What if your seed phrase is gone forever?
        </p>
        <p className="text-md md:text-lg mb-6">
          Hundreds of billions in crypto are already lost. You don’t want to be next.
        </p>
        <img
          src="https://res.cloudinary.com/dpmk8dg5g/image/upload/v1714042306/recova_mockup_final.png"
          alt="Recova Kit Mockup"
          className="w-full max-w-lg mx-auto rounded-xl border border-zinc-700 shadow-xl mb-10"
        />
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {[
            { icon: "🛡️", title: "Steel Backup", desc: "Indestructible metal plate for your 24 recovery words." },
            { icon: "🔐", title: "NFC Security", desc: "Encrypted NFC card – your second layer of secure validation." },
            { icon: "🔄", title: "Biometric Recovery", desc: "Trigger recovery using biometric confirmation and a backup wallet." },
            { icon: "🚫", title: "100% Offline", desc: "No cloud. No servers. No middlemen. Just you." }
          ].map(({ icon, title, desc }) => (
            <div key={title} className="bg-zinc-900 border border-zinc-700 shadow-md p-6 rounded-xl">
              <div className="text-3xl mb-2">{icon}</div>
              <h2 className="text-xl font-semibold mb-1">{title}</h2>
              <p className="text-white text-opacity-80">{desc}</p>
            </div>
          ))}
        </div>
        <p className="italic text-md md:text-lg mb-4">
          Recova is not just another “crypto backup.” It’s a mindset. A tool. A moment of calm in a chaotic digital world.
        </p>
        <p className="text-sm text-zinc-400 mb-6">Built by crypto users, for crypto users.</p>
        <button className="text-lg px-8 py-4 rounded-full bg-white text-black hover:bg-zinc-200 transition-all">
          Get Early Access
        </button>
        <p className="text-sm text-zinc-400 mt-4">Limited early access spots available.<br />No spam, ever. Just one email when we launch.</p>
      </div>
    </div>
  );
}
